import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.gridspec import GridSpec
import matplotlib.ticker as mticker
import warnings
warnings.filterwarnings('ignore')

# ── 字体配置 ──
import subprocess, os, sys
subprocess.run(['fc-cache','-f','-v'], capture_output=True)
plt.rcParams['font.family'] = ['WenQuanYi Micro Hei', 'Noto Sans CJK SC', 'SimHei', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False

BASE = "D:\\518活动调整"
UP   = "/mnt/user-data/uploads"

# ── 读取数据 ──
def p(name): return f"{UP}/{name}"

# 平台报表
plat = pd.read_excel(p("1779953323293_平台报表_USD_20260528091017.xlsx"))
plat['日期'] = pd.to_datetime(plat['日期'].astype(str), format='%Y%m%d')
for c in ['充值金额','提现金额','充提差','充提差比','投注金额','总赠送金额','总赠送充值比','充值人数','投注人数']:
    plat[c] = plat[c].astype(str).str.replace('%','').str.replace(',','')
    plat[c] = pd.to_numeric(plat[c], errors='coerce')
plat = plat.sort_values('日期').reset_index(drop=True)
plat['人均充值'] = plat['充值金额'] / plat['充值人数']
plat['人均投注'] = plat['投注金额'] / plat['投注人数']

# 活动数据
act = pd.read_csv(p("1779953323296_518调整活动的数据_全量数据_20260501_20260526.csv"))
act = act[act['时间'] != '阶段汇总'].copy()
act['时间'] = pd.to_datetime(act['时间'])
act = act.sort_values('时间').reset_index(drop=True)

CUTOFF = pd.Timestamp('2026-05-18')

def split(df, date_col='时间'):
    before = df[df[date_col] < CUTOFF]
    after  = df[df[date_col] >= CUTOFF]
    return before, after

plat_b, plat_a = split(plat, '日期')
act_b,  act_a  = split(act,  '时间')

# ── 留存数据 (汇总) ──
def load_retention(fname):
    df = pd.read_csv(p(fname))
    rows = {}
    for _, r in df.iterrows():
        if r['初始事件发生时间'] == '阶段值':
            rows[r['指标']] = r
    return rows

ret_files = {
    '团队代理佣金充值': '1779953323294_团队代理佣金充值留存_全量数据_20260501_20260526.csv',
    '团队代理佣金投注': '1779953323294_团队代理佣金投注留存_全量数据_20260501_20260526.csv',
    '团队代理邀请充值': '1779953323294_团队代理邀请充值留存_全量数据_20260501_20260526.csv',
    '团队代理邀请投注': '1779953323294_团队代理邀请投注留存_全量数据_20260501_20260526.csv',
    '幸运翻卡钻石充值': '1779953323295_幸运翻卡钻石充值留存_全量数据_20260501_20260526.csv',
    '幸运翻卡钻石投注': '1779953323295_幸运翻卡钻石投注留存_全量数据_20260501_20260526.csv',
    '幸运转盘充值':     '1779953323295_幸运转盘充值留存_全量数据_20260501_20260526.csv',
    '幸运转盘投注':     '1779953323295_幸运转盘投注留存_全量数据_20260501_20260526.csv',
    'VIP升级充值':      '1779953323296_VIP升级充值留存_全量数据_20260501_20260526.csv',
    'VIP升级投注':      '1779953323296_VIP升级投注留存_全量数据_20260501_20260526.csv',
}

# ── 颜色主题 ──
C_BEFORE = '#4A90D9'
C_AFTER  = '#E85D4A'
C_LINE   = '#2C3E50'
C_GRID   = '#F0F0F0'
C_ACCENT = '#F39C12'
BG       = '#FAFAFA'
CUTLINE  = '#E74C3C'

def styled_ax(ax, title='', ylabel='', xlabel=''):
    ax.set_facecolor(BG)
    ax.grid(axis='y', color=C_GRID, linewidth=0.8, zorder=0)
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.spines['left'].set_color('#CCCCCC')
    ax.spines['bottom'].set_color('#CCCCCC')
    if title: ax.set_title(title, fontsize=11, fontweight='bold', pad=8)
    if ylabel: ax.set_ylabel(ylabel, fontsize=9, color='#555')
    if xlabel: ax.set_xlabel(xlabel, fontsize=9, color='#555')
    ax.tick_params(labelsize=8, colors='#555')

def add_vline(ax, label='5/18调整'):
    ax.axvline(CUTOFF, color=CUTLINE, lw=1.5, ls='--', zorder=5)
    ax.text(CUTOFF, ax.get_ylim()[1]*0.97, label, color=CUTLINE, fontsize=8, ha='left', va='top')

def fmt_k(x, pos=None):
    if abs(x) >= 1e6: return f'{x/1e6:.1f}M'
    if abs(x) >= 1e3: return f'{x/1e3:.0f}K'
    return f'{x:.0f}'

# ═══════════════════════════════════════════
# 图1: 平台整体指标趋势（4图）
# ═══════════════════════════════════════════
fig1, axes = plt.subplots(2,2, figsize=(14,9))
fig1.patch.set_facecolor('white')
fig1.suptitle('平台整体指标趋势（5月1日—5月26日）', fontsize=14, fontweight='bold', y=0.98)

dates = plat['日期']

# 充提差 & 充提差比
ax = axes[0,0]
ax2 = ax.twinx()
bars = ax.bar(dates, plat['充提差'], color=[C_AFTER if d >= CUTOFF else C_BEFORE for d in dates], alpha=0.7, width=0.8, zorder=3)
ax2.plot(dates, plat['充提差比'], color=C_ACCENT, marker='o', ms=4, lw=1.8, zorder=4)
styled_ax(ax, '充提差 & 充提差比', '充提差 (USD)')
ax2.set_ylabel('充提差比 (%)', fontsize=9, color=C_ACCENT)
ax2.tick_params(labelsize=8, colors=C_ACCENT)
ax2.spines['top'].set_visible(False)
ax.yaxis.set_major_formatter(mticker.FuncFormatter(fmt_k))
ax.xaxis.set_major_formatter(matplotlib.dates.DateFormatter('%m/%d'))
plt.setp(ax.xaxis.get_majorticklabels(), rotation=45)
add_vline(ax)

# 充值金额 & 投注金额
ax = axes[0,1]
ax.plot(dates, plat['充值金额']/1e6, color=C_BEFORE, marker='o', ms=3, lw=1.8, label='充值金额')
ax.plot(dates, plat['投注金额']/1e6, color=C_AFTER,  marker='s', ms=3, lw=1.8, label='投注金额')
styled_ax(ax, '充值金额 & 投注金额趋势', '金额 (百万USD)')
ax.legend(fontsize=8)
ax.xaxis.set_major_formatter(matplotlib.dates.DateFormatter('%m/%d'))
plt.setp(ax.xaxis.get_majorticklabels(), rotation=45)
add_vline(ax)

# 总赠送金额 & 赠送充值比
ax = axes[1,0]
ax2 = ax.twinx()
ax.bar(dates, plat['总赠送金额'], color=[C_AFTER if d >= CUTOFF else C_BEFORE for d in dates], alpha=0.7, width=0.8, zorder=3)
ax2.plot(dates, plat['总赠送充值比'], color=C_ACCENT, marker='o', ms=4, lw=1.8, zorder=4)
styled_ax(ax, '赠送金额 & 赠送/充值比', '总赠送金额 (USD)')
ax2.set_ylabel('赠送/充值比 (%)', fontsize=9, color=C_ACCENT)
ax2.tick_params(labelsize=8, colors=C_ACCENT)
ax2.spines['top'].set_visible(False)
ax.yaxis.set_major_formatter(mticker.FuncFormatter(fmt_k))
ax.xaxis.set_major_formatter(matplotlib.dates.DateFormatter('%m/%d'))
plt.setp(ax.xaxis.get_majorticklabels(), rotation=45)
add_vline(ax)

# 人均充值 & 人均投注
ax = axes[1,1]
ax.plot(dates, plat['人均充值'], color=C_BEFORE, marker='o', ms=3, lw=1.8, label='人均充值')
ax.plot(dates, plat['人均投注'], color=C_AFTER,  marker='s', ms=3, lw=1.8, label='人均投注')
styled_ax(ax, '人均充值 & 人均投注趋势', 'USD/人')
ax.legend(fontsize=8)
ax.xaxis.set_major_formatter(matplotlib.dates.DateFormatter('%m/%d'))
plt.setp(ax.xaxis.get_majorticklabels(), rotation=45)
add_vline(ax)

# 图例说明
b_patch = mpatches.Patch(color=C_BEFORE, alpha=0.7, label='调整前(5/1-5/17)')
a_patch = mpatches.Patch(color=C_AFTER,  alpha=0.7, label='调整后(5/18-5/26)')
fig1.legend(handles=[b_patch, a_patch], loc='lower center', ncol=2, fontsize=9, frameon=False, bbox_to_anchor=(0.5,-0.01))
plt.tight_layout(rect=[0,0.03,1,0.97])
fig1.savefig('/mnt/user-data/outputs/fig1_platform_trends.png', dpi=150, bbox_inches='tight')
plt.close()
print("fig1 done")

# ═══════════════════════════════════════════
# 图2: 各活动赠送人数 & 赠送金额趋势
# ═══════════════════════════════════════════
activities = {
    '团队代理佣金': ('团队代理佣金赠送人数','团队代理佣金赠送金额'),
    'VIP升级':      ('VIP升级赠送人数','VIP升级赠送金额'),
    '幸运翻卡钻石': ('幸运翻卡钻石赠送人数','幸运翻卡钻石赠送金额'),
    '团队代理邀请': ('团队代理邀请赠送人数','团队代理邀请赠送金额'),
    '幸运转盘':     ('幸运转盘赠送人数','幸运转盘赠送金额'),
}

colors_act = ['#2980B9','#27AE60','#8E44AD','#E67E22','#16A085']
fig2, axes = plt.subplots(2,3, figsize=(16,9))
fig2.patch.set_facecolor('white')
fig2.suptitle('各活动赠送人数趋势（调整前后）', fontsize=14, fontweight='bold', y=0.99)
axs = axes.flatten()

for i, (name, (ppl_col, amt_col)) in enumerate(activities.items()):
    ax = axs[i]
    x = act['时间']
    color = colors_act[i]
    ax.bar(x, act[ppl_col], color=[C_AFTER if d >= CUTOFF else color for d in x], alpha=0.75, width=0.7, zorder=3)
    ax2 = ax.twinx()
    ax2.plot(x, act[amt_col], color='#E74C3C', marker='o', ms=3, lw=1.5, zorder=5)
    styled_ax(ax, name, '赠送人数')
    ax2.set_ylabel('赠送金额', fontsize=8, color='#E74C3C')
    ax2.tick_params(labelsize=7, colors='#E74C3C')
    ax2.spines['top'].set_visible(False)
    ax2.yaxis.set_major_formatter(mticker.FuncFormatter(fmt_k))
    ax.yaxis.set_major_formatter(mticker.FuncFormatter(fmt_k))
    ax.xaxis.set_major_formatter(matplotlib.dates.DateFormatter('%m/%d'))
    plt.setp(ax.xaxis.get_majorticklabels(), rotation=45, fontsize=7)
    add_vline(ax)

# 最后格子放汇总对比条形图
ax = axs[5]
names = list(activities.keys())
before_avg = [act_b[c[0]].mean() for c in activities.values()]
after_avg  = [act_a[c[0]].mean() for c in activities.values()]
x_pos = np.arange(len(names))
w = 0.35
ax.bar(x_pos-w/2, before_avg, w, color=C_BEFORE, alpha=0.8, label='调整前均值')
ax.bar(x_pos+w/2, after_avg,  w, color=C_AFTER,  alpha=0.8, label='调整后均值')
ax.set_xticks(x_pos); ax.set_xticklabels(names, fontsize=7, rotation=20)
ax.yaxis.set_major_formatter(mticker.FuncFormatter(fmt_k))
styled_ax(ax, '各活动赠送人数：调整前后均值对比', '日均赠送人数')
ax.legend(fontsize=8)

fig2.tight_layout(rect=[0,0,1,0.97])
fig2.savefig('/mnt/user-data/outputs/fig2_activity_people.png', dpi=150, bbox_inches='tight')
plt.close()
print("fig2 done")

# ═══════════════════════════════════════════
# 图3: 人均赠送金额 & 充提差
# ═══════════════════════════════════════════
fig3, axes = plt.subplots(2,3, figsize=(16,9))
fig3.patch.set_facecolor('white')
fig3.suptitle('各活动充值金额 & 充提差趋势', fontsize=14, fontweight='bold', y=0.99)
axs = axes.flatten()

charge_cols = {
    '团队代理佣金': ('团队代理佣金赠送人数','团队代理佣金充值金额','团队代理佣金提款金额'),
    'VIP升级':      ('VIP升级赠送人数','VIP升级充值金额','VIP升级提款金额'),
    '幸运翻卡钻石': ('幸运翻卡钻石赠送人数','幸运翻卡-钻石充值金额','幸运翻卡-钻石提款金额'),
    '团队代理邀请': ('团队代理邀请赠送人数','团队代理邀请充值金额','团队代理邀请提款金额'),
    '幸运转盘':     ('幸运转盘赠送人数','幸运转盘充值金额','幸运转盘提款金额'),
}

for i, (name, (ppl, chg_col, wdl_col)) in enumerate(charge_cols.items()):
    ax = axs[i]
    color = colors_act[i]
    x = act['时间']
    diff = act[chg_col] - act[wdl_col]
    avg_bonus = act[chg_col] / act[ppl].replace(0,np.nan)
    ax.bar(x, diff, color=[C_AFTER if d >= CUTOFF else color for d in x], alpha=0.75, width=0.7, zorder=3, label='充提差')
    ax2 = ax.twinx()
    ax2.plot(x, avg_bonus, color='#8E44AD', marker='o', ms=3, lw=1.5, zorder=5)
    styled_ax(ax, f'{name} 充提差 & 人均充值', '充提差(USD)')
    ax2.set_ylabel('人均充值', fontsize=8, color='#8E44AD')
    ax2.tick_params(labelsize=7, colors='#8E44AD')
    ax2.spines['top'].set_visible(False)
    ax.yaxis.set_major_formatter(mticker.FuncFormatter(fmt_k))
    ax2.yaxis.set_major_formatter(mticker.FuncFormatter(fmt_k))
    ax.xaxis.set_major_formatter(matplotlib.dates.DateFormatter('%m/%d'))
    plt.setp(ax.xaxis.get_majorticklabels(), rotation=45, fontsize=7)
    add_vline(ax)

# 综合充提差比较
ax = axs[5]
names = list(charge_cols.keys())
before_diff = []
after_diff  = []
for name,(ppl,chg,wdl) in charge_cols.items():
    before_diff.append((act_b[chg]-act_b[wdl]).mean())
    after_diff.append((act_a[chg]-act_a[wdl]).mean())
x_pos = np.arange(len(names))
ax.bar(x_pos-w/2, before_diff, w, color=C_BEFORE, alpha=0.8, label='调整前')
ax.bar(x_pos+w/2, after_diff,  w, color=C_AFTER,  alpha=0.8, label='调整后')
ax.set_xticks(x_pos); ax.set_xticklabels(names, fontsize=7, rotation=20)
ax.yaxis.set_major_formatter(mticker.FuncFormatter(fmt_k))
styled_ax(ax, '各活动日均充提差对比', 'USD')
ax.legend(fontsize=8)

fig3.tight_layout(rect=[0,0,1,0.97])
fig3.savefig('/mnt/user-data/outputs/fig3_activity_diff.png', dpi=150, bbox_inches='tight')
plt.close()
print("fig3 done")

# ═══════════════════════════════════════════
# 图4: 投注金额趋势
# ═══════════════════════════════════════════
fig4, axes = plt.subplots(2,3, figsize=(16,9))
fig4.patch.set_facecolor('white')
fig4.suptitle('各活动投注金额趋势', fontsize=14, fontweight='bold', y=0.99)
axs = axes.flatten()

bet_cols = {
    '团队代理佣金': '团队代理佣金投注金额',
    'VIP升级':      'VIP升级投注金额',
    '幸运翻卡钻石': '幸运翻卡-钻石投注金额',
    '团队代理邀请': '团队代理邀请投注金额',
    '幸运转盘':     '幸运转盘投注金额',
}

for i,(name,col) in enumerate(bet_cols.items()):
    ax = axs[i]
    color = colors_act[i]
    x = act['时间']
    ax.fill_between(x, act[col], alpha=0.3, color=color)
    ax.plot(x, act[col], color=color, lw=1.8, marker='o', ms=3)
    styled_ax(ax, f'{name} 投注金额', 'USD')
    ax.yaxis.set_major_formatter(mticker.FuncFormatter(fmt_k))
    ax.xaxis.set_major_formatter(matplotlib.dates.DateFormatter('%m/%d'))
    plt.setp(ax.xaxis.get_majorticklabels(), rotation=45, fontsize=7)
    add_vline(ax)
    # before/after avg
    b_avg = act_b[col].mean(); a_avg = act_a[col].mean()
    chg = (a_avg-b_avg)/b_avg*100
    ax.text(0.97, 0.97, f'变化: {chg:+.1f}%', transform=ax.transAxes,
            ha='right', va='top', fontsize=8, color=CUTLINE if chg<0 else '#27AE60',
            bbox=dict(boxstyle='round,pad=0.2', facecolor='white', alpha=0.7))

# 总投注
ax = axs[5]
x = plat['日期']
ax.fill_between(x, plat['投注金额']/1e6, alpha=0.3, color=C_LINE)
ax.plot(x, plat['投注金额']/1e6, color=C_LINE, lw=2, marker='o', ms=3)
styled_ax(ax, '平台总投注金额', '百万USD')
ax.xaxis.set_major_formatter(matplotlib.dates.DateFormatter('%m/%d'))
plt.setp(ax.xaxis.get_majorticklabels(), rotation=45, fontsize=7)
add_vline(ax)

fig4.tight_layout(rect=[0,0,1,0.97])
fig4.savefig('/mnt/user-data/outputs/fig4_bet_amount.png', dpi=150, bbox_inches='tight')
plt.close()
print("fig4 done")

# ═══════════════════════════════════════════
# 图5: 关键指标前后对比（汇总雷达 + 变化幅度）
# ═══════════════════════════════════════════
fig5, axes = plt.subplots(1,2, figsize=(14,6))
fig5.patch.set_facecolor('white')
fig5.suptitle('调整前后关键指标对比分析', fontsize=14, fontweight='bold', y=1.01)

# 左：充提差比 & 赠送充值比 趋势
ax = axes[0]
ax.plot(plat['日期'], plat['充提差比'], color=C_BEFORE, marker='o', ms=4, lw=2, label='充提差比(%)')
ax.plot(plat['日期'], plat['总赠送充值比'], color=C_ACCENT, marker='s', ms=4, lw=2, label='赠送/充值比(%)')
ax.axvline(CUTOFF, color=CUTLINE, lw=2, ls='--')
ax.text(CUTOFF, ax.get_ylim()[1]*0.9, '5/18调整', color=CUTLINE, fontsize=9)
# 区间均值标注
b_diff_ratio = plat_b['充提差比'].mean()
a_diff_ratio = plat_a['充提差比'].mean()
b_bon_ratio  = plat_b['总赠送充值比'].mean()
a_bon_ratio  = plat_a['总赠送充值比'].mean()
ax.axhline(b_diff_ratio, xmin=0, xmax=17/25, color=C_BEFORE, lw=1, ls=':', alpha=0.6)
ax.axhline(a_diff_ratio, xmin=17/25, xmax=1, color=C_AFTER, lw=1, ls=':', alpha=0.6)
styled_ax(ax, '充提差比 & 赠送充值比趋势', '%')
ax.legend(fontsize=9)
ax.xaxis.set_major_formatter(matplotlib.dates.DateFormatter('%m/%d'))
plt.setp(ax.xaxis.get_majorticklabels(), rotation=45)

# 右：各活动赠送金额前后均值变化
ax = axes[1]
metrics = {
    '总赠送金额\n(万USD)':  (plat_b['总赠送金额'].mean()/1e4, plat_a['总赠送金额'].mean()/1e4),
    '充提差\n(万USD)':      (plat_b['充提差'].mean()/1e4,      plat_a['充提差'].mean()/1e4),
    '人均充值\n(USD)':      (plat_b['人均充值'].mean(),         plat_a['人均充值'].mean()),
    '人均投注\n(USD)':      (plat_b['人均投注'].mean(),         plat_a['人均投注'].mean()),
}
names = list(metrics.keys())
b_vals = [v[0] for v in metrics.values()]
a_vals = [v[1] for v in metrics.values()]
x_pos = np.arange(len(names))
w = 0.35
bars_b = ax.bar(x_pos-w/2, b_vals, w, color=C_BEFORE, alpha=0.85, label='调整前均值')
bars_a = ax.bar(x_pos+w/2, a_vals, w, color=C_AFTER,  alpha=0.85, label='调整后均值')
for xp, bv, av in zip(x_pos, b_vals, a_vals):
    pct = (av-bv)/abs(bv)*100 if bv != 0 else 0
    color = '#27AE60' if pct > 0 else CUTLINE
    ax.text(xp+w/2, av*1.02, f'{pct:+.1f}%', ha='center', fontsize=8, color=color, fontweight='bold')
ax.set_xticks(x_pos); ax.set_xticklabels(names, fontsize=9)
styled_ax(ax, '关键指标调整前后均值对比', '数值')
ax.legend(fontsize=9)
ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x,p: f'{x:.0f}'))

fig5.tight_layout()
fig5.savefig('/mnt/user-data/outputs/fig5_key_metrics.png', dpi=150, bbox_inches='tight')
plt.close()
print("fig5 done")

# ═══════════════════════════════════════════
# 图6: 人均赠送金额对比
# ═══════════════════════════════════════════
fig6, axes = plt.subplots(1,2, figsize=(14,6))
fig6.patch.set_facecolor('white')
fig6.suptitle('各活动人均赠送金额 & 赠送比分析', fontsize=14, fontweight='bold', y=1.01)

# 人均赠送金额（调整前后）
ax = axes[0]
act_names = list(activities.keys())
b_per_person, a_per_person = [], []
for name,(ppl,amt) in activities.items():
    b_per_person.append((act_b[amt]/act_b[ppl].replace(0,np.nan)).mean())
    a_per_person.append((act_a[amt]/act_a[ppl].replace(0,np.nan)).mean())
x_pos = np.arange(len(act_names))
ax.bar(x_pos-w/2, b_per_person, w, color=C_BEFORE, alpha=0.85, label='调整前')
ax.bar(x_pos+w/2, a_per_person, w, color=C_AFTER,  alpha=0.85, label='调整后')
for xp, bv, av in zip(x_pos, b_per_person, a_per_person):
    if bv and not np.isnan(bv):
        pct = (av-bv)/abs(bv)*100
        color = '#27AE60' if pct > 0 else CUTLINE
        ax.text(xp+w/2, av*1.02, f'{pct:+.1f}%', ha='center', fontsize=8, color=color, fontweight='bold')
ax.set_xticks(x_pos); ax.set_xticklabels(act_names, fontsize=8, rotation=10)
styled_ax(ax, '各活动日均人均赠送金额对比', 'USD/人')
ax.legend(fontsize=9)

# 各活动赠送金额 vs 充值金额比
ax = axes[1]
b_ratio, a_ratio = [], []
for name,(ppl,amt) in activities.items():
    chg_col = charge_cols[name][1]
    b_ratio.append((act_b[amt]/act_b[chg_col].replace(0,np.nan)*100).mean())
    a_ratio.append((act_a[amt]/act_a[chg_col].replace(0,np.nan)*100).mean())

ax.bar(x_pos-w/2, b_ratio, w, color=C_BEFORE, alpha=0.85, label='调整前')
ax.bar(x_pos+w/2, a_ratio, w, color=C_AFTER,  alpha=0.85, label='调整后')
for xp, bv, av in zip(x_pos, b_ratio, a_ratio):
    if bv and not np.isnan(bv):
        pct = av - bv
        color = '#27AE60' if pct < 0 else CUTLINE
        ax.text(xp+w/2, av*1.02, f'{pct:+.1f}pp', ha='center', fontsize=8, color=color, fontweight='bold')
ax.set_xticks(x_pos); ax.set_xticklabels(act_names, fontsize=8, rotation=10)
styled_ax(ax, '各活动赠送/充值比对比', '%')
ax.legend(fontsize=9)

fig6.tight_layout()
fig6.savefig('/mnt/user-data/outputs/fig6_per_person.png', dpi=150, bbox_inches='tight')
plt.close()
print("fig6 done")

# ═══════════════════════════════════════════
# 计算打印关键统计
# ═══════════════════════════════════════════
print("\n" + "="*60)
print("关键指标汇总")
print("="*60)

def pct_chg(b, a):
    if b == 0: return float('inf')
    return (a - b) / abs(b) * 100

print(f"\n【平台整体】调整前(5/1-5/17) vs 调整后(5/18-5/26)")
metrics_summary = {
    '充提差(日均)': (plat_b['充提差'].mean(), plat_a['充提差'].mean()),
    '充提差比(日均)': (plat_b['充提差比'].mean(), plat_a['充提差比'].mean()),
    '总赠送金额(日均)': (plat_b['总赠送金额'].mean(), plat_a['总赠送金额'].mean()),
    '赠送/充值比(日均)': (plat_b['总赠送充值比'].mean(), plat_a['总赠送充值比'].mean()),
    '充值金额(日均)': (plat_b['充值金额'].mean(), plat_a['充值金额'].mean()),
    '投注金额(日均)': (plat_b['投注金额'].mean(), plat_a['投注金额'].mean()),
    '人均充值': (plat_b['人均充值'].mean(), plat_a['人均充值'].mean()),
    '人均投注': (plat_b['人均投注'].mean(), plat_a['人均投注'].mean()),
}
for k,(b,a) in metrics_summary.items():
    print(f"  {k}: {b:.2f} → {a:.2f}  ({pct_chg(b,a):+.1f}%)")

print(f"\n【各活动日均赠送人数】")
for name,(ppl,amt) in activities.items():
    b = act_b[ppl].mean(); a = act_a[ppl].mean()
    print(f"  {name}: {b:.0f} → {a:.0f}  ({pct_chg(b,a):+.1f}%)")

print(f"\n【各活动日均赠送金额】")
for name,(ppl,amt) in activities.items():
    b = act_b[amt].mean(); a = act_a[amt].mean()
    print(f"  {name}: {b:.0f} → {a:.0f}  ({pct_chg(b,a):+.1f}%)")

print(f"\n【各活动日均充提差】")
for name,(ppl,chg,wdl) in charge_cols.items():
    b = (act_b[chg]-act_b[wdl]).mean(); a = (act_a[chg]-act_a[wdl]).mean()
    print(f"  {name}: {b:.0f} → {a:.0f}  ({pct_chg(b,a):+.1f}%)")

print(f"\n【各活动日均投注金额】")
for name,col in bet_cols.items():
    b = act_b[col].mean(); a = act_a[col].mean()
    print(f"  {name}: {b:.0f} → {a:.0f}  ({pct_chg(b,a):+.1f}%)")

